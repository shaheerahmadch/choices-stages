/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ChoicesStages/index.ts":
/*!********************************!*\
  !*** ./ChoicesStages/index.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ChoicesStages = void 0;\nvar ChoicesStages = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function ChoicesStages() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  ChoicesStages.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Track all the things\n    var _a, _b, _c;\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    this.isEditMode = false; // Create the span element to hold the project name\n    var Container = document.createElement(\"div\");\n    var br = document.createElement(\"br\");\n    this.container.appendChild(Container);\n    var title = document.createElement(\"span\");\n    var ul = document.createElement('ul');\n    ul.classList.add('fluent-list');\n    title.classList.add(\"my-title\");\n    var choiceName = (_a = context.parameters.Choice.attributes) === null || _a === void 0 ? void 0 : _a.DisplayName;\n    var choiceLogicalName = (_b = context.parameters.Choice.attributes) === null || _b === void 0 ? void 0 : _b.LogicalName;\n    var choices = (_c = context.parameters.Choice.attributes) === null || _c === void 0 ? void 0 : _c.Options;\n    var entityLogicalName = context.parameters.entityName.raw;\n    var recordID = context.parameters.entityId.raw;\n    if (choiceName != undefined) {\n      title.innerText = choiceName;\n    } else {\n      title.innerText = \"undefined\";\n    }\n    var currentValue = 0;\n    context.webAPI.retrieveRecord(entityLogicalName, recordID).then(function (result) {\n      currentValue = result[choiceLogicalName];\n      console.log(currentValue);\n      if (choices != undefined) {\n        choices.forEach(function (item) {\n          var li = document.createElement('li');\n          li.classList.add('fluent-list-item');\n          li.textContent = item.Label;\n          li.addEventListener('click', function () {\n            ul.querySelectorAll('.fluent-list-item').forEach(function (item) {\n              item.classList.remove('active');\n            });\n            // Add \"active\" class to the clicked list item\n            li.classList.add('active');\n            // Update the Choice property value\n            var data = {};\n            data[choiceLogicalName] = item.Value;\n            context.webAPI.updateRecord(entityLogicalName, recordID, data).then(function () {\n              console.log(\"success\");\n              notifyOutputChanged();\n            });\n          });\n          console.log(item.Value + \",\" + currentValue);\n          if (item.Value == currentValue) {\n            li.classList.add(\"active\");\n          }\n          ul.appendChild(li);\n        });\n      }\n    });\n    Container.appendChild(title);\n    Container.appendChild(br);\n    Container.appendChild(ul);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  ChoicesStages.prototype.updateView = function (context) {\n    // Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  ChoicesStages.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  ChoicesStages.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return ChoicesStages;\n}();\nexports.ChoicesStages = ChoicesStages;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoicesStages/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ChoicesStages/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ShaheerAhmad.ChoicesStages', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoicesStages);
} else {
	var ShaheerAhmad = ShaheerAhmad || {};
	ShaheerAhmad.ChoicesStages = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoicesStages;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}