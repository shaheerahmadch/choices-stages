/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ChoicesStages/index.ts":
/*!********************************!*\
  !*** ./ChoicesStages/index.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ChoicesStages = void 0;\nvar ChoicesStages = /** @class */function () {\n  function ChoicesStages() {}\n  ChoicesStages.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a, _b;\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    this.isEditMode = false; // Create the span element to hold the project name\n    var Container = document.createElement(\"div\");\n    var br = document.createElement(\"br\");\n    this.container.appendChild(Container);\n    var title = document.createElement(\"span\");\n    var ul = document.createElement('ul');\n    ul.classList.add('fluent-list');\n    title.classList.add(\"my-title\");\n    var choiceName = (_a = context.parameters.Choice.attributes) === null || _a === void 0 ? void 0 : _a.DisplayName;\n    var choices = (_b = context.parameters.Choice.attributes) === null || _b === void 0 ? void 0 : _b.Options;\n    var selectedValue = this.context.parameters.Choice.raw;\n    if (choiceName != undefined) {\n      title.innerText = choiceName;\n    } else {\n      title.innerText = \"undefined\";\n    }\n    if (choices != undefined) {\n      choices.forEach(function (item) {\n        var li = document.createElement('li');\n        li.classList.add('fluent-list-item');\n        li.textContent = item.Label;\n        li.addEventListener('click', function () {\n          ul.querySelectorAll('.fluent-list-item').forEach(function (item) {\n            item.classList.remove('active');\n          });\n          li.classList.add('active');\n          context.parameters.Choice.raw = item.Value;\n          notifyOutputChanged();\n        });\n        if (item.Value == selectedValue) {\n          li.classList.add(\"active\");\n        }\n        ul.appendChild(li);\n      });\n    }\n    Container.appendChild(title);\n    Container.appendChild(br);\n    Container.appendChild(ul);\n  };\n  ChoicesStages.prototype.updateView = function (context) {\n    // Add code to update control view\n  };\n  ChoicesStages.prototype.getOutputs = function () {\n    var _a;\n    return {\n      Choice: (_a = this.context.parameters.Choice.raw) !== null && _a !== void 0 ? _a : undefined\n    };\n  };\n  ChoicesStages.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return ChoicesStages;\n}();\nexports.ChoicesStages = ChoicesStages;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ChoicesStages/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ChoicesStages/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ShaheerAhmad.ChoicesStages', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoicesStages);
} else {
	var ShaheerAhmad = ShaheerAhmad || {};
	ShaheerAhmad.ChoicesStages = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ChoicesStages;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}